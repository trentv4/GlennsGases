package net.trentv.gases.heatedbuilder;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import javax.imageio.ImageIO;

//pls no messaging me about code quality. it works and that's all that matters.
public class Main
{
	public static void main(String[] args)
	{
		try
		{
			run();
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private static final void run() throws Exception
	{
		BufferedReader reader = new BufferedReader(new FileReader(new File("name.txt")));
		ArrayList<String> arr = new ArrayList<String>();
		String s = reader.readLine();
		while(s != null)
		{
			arr.add(s);
			s = reader.readLine();
		}
		reader.close();
		BufferedImage all = new BufferedImage(176, arr.size()*16, BufferedImage.TYPE_INT_ARGB);
		for(int i = 0; i < arr.size(); i++)
		{
			System.out.println("Processing: " + arr.get(i));
			process(arr.get(i), i*16, all);
		}
	}
	
	private static void process(String in, int yoffset, BufferedImage all) throws Exception
	{
		BufferedImage image = ImageIO.read(new File(in + ".png"));
		all.getGraphics().drawImage(image, 0, yoffset, null);
		for(int i = 0; i < 6; i++)
		{
			BufferedImage a = ImageIO.read(new File(in + ".png"));
			BufferedImage b = ImageIO.read(new File("files/" + i + ".png"));
			Graphics2D ag = (Graphics2D) a.getGraphics();
			float transparency = (30 + (30*i));
			transparency = transparency / 255;
			ag.setComposite(AlphaComposite.getInstance(AlphaComposite.SrcOver.getRule(), transparency));
			ag.drawImage(b, 0, 0, null);
			all.getGraphics().drawImage(a, 16+ i*16, yoffset, null);
			ImageIO.write(a, "png", new File("out/heated_"+ in +"_"+ i + ".png"));
		}
		for(int i = 6; i < 9; i++)
		{
			BufferedImage a = ImageIO.read(new File(in + ".png"));
			BufferedImage b = ImageIO.read(new File("files/6_" + (i-6) + ".png"));
			Graphics2D ag = (Graphics2D) a.getGraphics();
			float transparency = 210;
			transparency = transparency / 255;
			ag.setComposite(AlphaComposite.getInstance(AlphaComposite.SrcOver.getRule(), transparency));
			ag.drawImage(b, 0, 0, null);
			all.getGraphics().drawImage(a, 16+ i*16, yoffset, null);
			ImageIO.write(a, "png", new File("out/heated_"+in+"_6_" + (i-6) + ".png"));
		}
		BufferedImage a = ImageIO.read(new File(in + ".png"));
		BufferedImage b = ImageIO.read(new File("files/7.png"));
		Graphics2D ag = (Graphics2D) a.getGraphics();
		float transparency = 240;
		transparency = transparency / 255;
		ag.setComposite(AlphaComposite.getInstance(AlphaComposite.SrcOver.getRule(), transparency));
		ag.drawImage(b, 0, 0, null);
		all.getGraphics().drawImage(a, 160, yoffset, null);
		ImageIO.write(a, "png", new File("out/heated_"+in+"_7.png"));
		
		ImageIO.write(all, "png", new File("out/all.png"));
	}
}
