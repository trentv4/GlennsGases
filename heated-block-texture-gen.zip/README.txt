This is the tool I use to generate the textures I need for heated stone. I provide it to you so you don't have to go through the hassle of making the textures manually. 

To use it: 

* edit "name.txt" with the names of the png files you want as the base.
* ensure that the same file exists in the directory as a png (ex. "diamond" -> diamond.png)
* ensure the files in "files/" exists and "out/" exists
* run gen.jar and collect the files from out

The program is set up ahead of time to process "diamond" as an example.

I provide the source under MIT license and the files under Creative Commons (attribution required). Have fun!

-- Trentv4